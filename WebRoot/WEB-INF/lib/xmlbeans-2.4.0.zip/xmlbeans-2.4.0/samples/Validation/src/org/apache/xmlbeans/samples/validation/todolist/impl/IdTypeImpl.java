/*
 * XML Type:  idType
 * Namespace: http://xmlbeans.apache.org/samples/validation/todolist
 * Java type: org.apache.xmlbeans.samples.validation.todolist.IdType
 *
 * Automatically generated - do not modify.
 */
package org.apache.xmlbeans.samples.validation.todolist.impl;
/**
 * An XML idType(@http://xmlbeans.apache.org/samples/validation/todolist).
 *
 * This is an atomic type that is a restriction of org.apache.xmlbeans.XmlInt.
 */
public class IdTypeImpl extends org.apache.xmlbeans.impl.values.JavaIntHolderEx implements org.apache.xmlbeans.samples.validation.todolist.IdType
{
    
    public IdTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType, false);
    }
    
    protected IdTypeImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
    {
        super(sType, b);
    }
}
