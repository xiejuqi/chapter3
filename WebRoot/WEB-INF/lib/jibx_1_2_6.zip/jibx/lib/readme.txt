This directory contains the dependent jar files and the jibx-xxx.jar files that are built.

You will need to run the ivy command to add the dependent jars.
> cd core/build
> ant -f build-ivy.xml
You will need to run the build script to build the jibx jar files.
> ant
