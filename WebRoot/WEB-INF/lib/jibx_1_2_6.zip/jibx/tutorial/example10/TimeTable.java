
package example10;

import java.util.ArrayList;
import java.util.LinkedList;

public class TimeTable
{
    private ArrayList carriers;
    private Object[] airports;
}
