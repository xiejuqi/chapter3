
package example5;

public class Customer {
    public int customerNumber;
    public String firstName;
    public String lastName;
    public String street;
    public String city;
    public String state;
    public Integer zip;
    public String phone;
}
