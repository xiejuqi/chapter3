
package example13;

public class Customer {
    public int customerNumber;
    public String firstName;
    public String lastName;
    public Object address;
    public String phone;
}
