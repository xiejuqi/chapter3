
package example21;

public class Name {
    private String firstName;
    private String lastName;
}
