
package example7;

public class Person {
    public int customerNumber;
    public String firstName;
    public String lastName;
}
